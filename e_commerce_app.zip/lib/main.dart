import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false, // Add this line
      home: MyEcommerceApp(),
    ),
  );
}

class MyEcommerceApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ecommerce App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: ProductListingPage(),
    );
  }
}

class Product {
  final String name;
  final String imageUrl;
  final String description;
  final double price;
  final String category;

  Product({
    required this.name,
    required this.imageUrl,
    required this.description,
    required this.price,
    required this.category,
  });
}

class ProductListingPage extends StatelessWidget {
  final List<Product> products = [
    Product(
      name: "ARAMISH Men's Genuine Leather Lace Up Formal Shoes",
      imageUrl: "images/img4.jpeg",
      description: "Description for Product 1",
      price: 19.99,
      category: "Watches",
    ),
    Product(
      name: "TIMEX Analog Men's Watch (Dial Colored Strap)",
      imageUrl: "images/img5.jpeg",
      description: "Description for Product 2",
      price: 29.99,
      category: "Watches",
    ),
    Product(
      name: "IQOO Z9 5G",
      imageUrl: "images/img6.png",
      description: "Description for Product 3",
      price: 400.23,
      category: "Smartphones",
    ),
    Product(
      name: "Samsung Galaxy S21 Ultra",
      imageUrl: "images/S21.jpg",
      description: "Description for Product 4",
      price: 1299.99,
      category: "Smartphones",
    ),
    Product(
      name: "iPhone 13 Pro Max",
      imageUrl: "images/iphone13.webp",
      description: "Description for Product 5",
      price: 1399.99,
      category: "Smartphones",
    ),
    Product(
      name: "Samsung 65-inch Smart TV",
      imageUrl: "images/samsung_tv.webp",
      description: "Description for Product 6",
      price: 1499.99,
      category: "Mobiles",
    ),
    Product(
      name: "Apple iPad Air",
      imageUrl: "images/apple_ipad_air.webp",
      description: "Description for Product 7",
      price: 599.99,
      category: "Mobiles",
    ),
    Product(
      name: "LG Refrigerator",
      imageUrl: "images/LG.webp",
      description: "Description for Product 8",
      price: 999.99,
      category: "Groceries",
    ),
    // Add more products with their respective details
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Icon(Icons.search), // Adding search icon
                SizedBox(width: 8.0), // Adding space between icons and title
                Text(
                  "My Ecommerce App",
                  style: TextStyle(fontSize: 18.0), // Reduced font size
                ),
              ],
            ),
            IconButton(
              icon: Icon(Icons.shopping_cart), // Adding cart icon
              onPressed: () {
                // Handle cart icon press here
              },
            ),
          ],
        ),
        actions: [
          PopupMenuButton(
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem(
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SettingsPage()),
                      );
                    },
                    child: Text('Settings'),
                  ),
                ),
                PopupMenuItem(
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginPage()),
                      );
                    },
                    child: Text('Login'),
                  ),
                ),
                PopupMenuItem(
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => CategoryPage()),
                      );
                    },
                    child: Text('Categories'),
                  ),
                ),
              ];
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 200,
              color: Colors.blue,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  Container(
                    width: 350.0,
                    height: 150.0,
                    color: Colors.red,
                    child: Center(child: Image.asset('images/img1.jpeg')),
                  ),
                  SizedBox(width: 16.0),
                  Container(
                    width: 350.0,
                    color: Colors.green,
                    child: Center(child: Image.asset('images/img2.jpeg')),
                  ),
                  SizedBox(width: 16.0),
                  Container(
                    width: 350.0,
                    color: Colors.blue,
                    child: Center(child: Image.asset('images/img3.jpeg')),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.0),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                "Products",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 8.0),
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: products.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            ProductDetailPage(product: products[index]),
                      ),
                    );
                  },
                  child: Card(
                    margin: EdgeInsets.fromLTRB(16.0, 8.0, 16.0, 8.0),
                    elevation: 4.0,
                    child: Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                          Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.0),
                              image: DecorationImage(
                                image: AssetImage(products[index].imageUrl),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          SizedBox(width: 16.0),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  products[index].name,
                                  style: TextStyle(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.bold),
                                ),
                                SizedBox(height: 4.0),
                                Text(
                                  "\$${products[index].price.toStringAsFixed(2)}",
                                  style: TextStyle(
                                      fontSize: 14.0, color: Colors.blue),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class ProductDetailPage extends StatelessWidget {
  final Product product;

  ProductDetailPage({required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Product Details"),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              product.imageUrl,
              fit: BoxFit.cover,
              width: MediaQuery.of(context).size.width,
              height: 300.0,
            ),
            Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style:
                        TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    "\$${product.price.toStringAsFixed(2)}",
                    style: TextStyle(fontSize: 20.0, color: Colors.blue),
                  ),
                  SizedBox(height: 16.0),
                  Text(
                    product.description,
                    style: TextStyle(fontSize: 16.0),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CategoryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Categories"),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          InkWell(
            onTap: () {
              // Handle watches category
            },
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
              child: Text(
                "Watches",
                style: TextStyle(fontSize: 18.0),
              ),
            ),
          ),
          InkWell(
            onTap: () {
              // Handle smartphones category
            },
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
              child: Text(
                "Smartphones",
                style: TextStyle(fontSize: 18.0),
              ),
            ),
          ),
          InkWell(
            onTap: () {
              // Handle mobiles category
            },
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
              child: Text(
                "Mobiles",
                style: TextStyle(fontSize: 18.0),
              ),
            ),
          ),
          InkWell(
            onTap: () {
              // Handle groceries category
            },
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
              child: Text(
                "Groceries",
                style: TextStyle(fontSize: 18.0),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Settings"),
      ),
      body: Center(
        child: Text("Settings Page"),
      ),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton.icon(
              onPressed: () {
                // Handle Facebook login
              },
              icon: Image.asset(
                'images/facebook.jpeg',
                height: 24.0,
                width: 24.0,
              ),
              label: Text('Login with Facebook'),
              style: ElevatedButton.styleFrom(
                primary: Colors.blue,
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton.icon(
              onPressed: () {
                // Handle Google login
              },
              icon: Image.asset(
                'images/google.jpeg',
                height: 24.0,
                width: 24.0,
              ),
              label: Text('Login with Google'),
              style: ElevatedButton.styleFrom(
                primary: Colors.red,
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton.icon(
              onPressed: () {
                // Handle mobile number login
              },
              icon: Icon(Icons.phone),
              label: Text('Login with Mobile Number'),
              style: ElevatedButton.styleFrom(
                primary: Colors.green,
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton.icon(
              onPressed: () {
                // Handle Twitter login
              },
              icon: Image.asset(
                'images/twitter.jpeg',
                height: 24.0,
                width: 24.0,
              ),
              label: Text('Login with Twitter'),
              style: ElevatedButton.styleFrom(
                primary: Colors.lightBlue,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
